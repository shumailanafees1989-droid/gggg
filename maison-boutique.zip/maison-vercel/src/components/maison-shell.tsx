import { Link } from "@tanstack/react-router";
import { Menu, Search, ShoppingBag, UserRound, X } from "lucide-react";
import { useState, type ReactNode } from "react";

const navigation = [
  { label: "Home", to: "/" as const },
  { label: "Collection", to: "/collection" as const },
  { label: "New Arrivals", to: "/new-arrivals" as const },
  { label: "About", to: "/about" as const },
  { label: "Cart", to: "/cart" as const },
];

export function MaisonShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [searching, setSearching] = useState(false);
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-border/60 bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 lg:px-10">
          <Link to="/" className="flex items-center gap-3" aria-label="Maison home">
            <span className="grid size-8 place-items-center border border-foreground font-display text-lg italic">M</span>
            <span className="font-display text-xl uppercase tracking-[0.24em]">Maison</span>
          </Link>
          <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
            {navigation.map((item) => (
              <Link key={item.to} to={item.to} activeOptions={{ exact: item.to === "/" }} className="nav-link">
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <button className="icon-button" aria-label="Search" onClick={() => setSearching((value) => !value)}><Search size={18} /></button>
            <button className="icon-button hidden sm:grid" aria-label="Account"><UserRound size={18} /></button>
            <button className="icon-button md:hidden" aria-label="Menu" onClick={() => setOpen((value) => !value)}>{open ? <X size={20} /> : <Menu size={20} />}</button>
          </div>
        </div>
        {searching && <form className="mx-auto flex max-w-7xl gap-3 border-t border-border px-5 py-3" onSubmit={(event) => event.preventDefault()}><input autoFocus className="field flex-1" placeholder="Search the collection" aria-label="Search collection"/><button className="button-dark" type="submit">Search</button></form>}
        {open && <nav className="grid border-t border-border bg-background px-5 py-5 md:hidden">{navigation.map((item) => <Link key={item.to} to={item.to} className="border-b border-border py-4 text-xs uppercase tracking-[0.18em]" onClick={() => setOpen(false)}>{item.label}</Link>)}</nav>}
      </header>
      <main className="pt-20">{children}</main>
      <Footer />
    </div>
  );
}

function Footer() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  return <footer className="bg-footer text-footer-foreground">
    <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-[1.6fr_1fr_1fr_1.4fr] lg:px-10">
      <div><div className="font-display text-2xl uppercase tracking-[0.22em]">Maison</div><p className="mt-3 text-xs uppercase tracking-[0.18em] text-footer-muted">Avenue Montaigne, Paris</p></div>
      <div><p className="footer-title">Navigation</p><Link to="/collection">Collection</Link><Link to="/new-arrivals">New Arrivals</Link></div>
      <div><p className="footer-title">Client Care</p><a href="mailto:concierge@maison-boutique.com">Shipping & Returns</a><a href="mailto:concierge@maison-boutique.com">Contact Us</a></div>
      <div><p className="footer-title">Newsletter</p><p className="mb-4 text-sm text-footer-muted">Subscribe to receive private invitations.</p>{sent ? <p className="text-sm">Welcome to the Maison registry.</p> : <form className="flex border-b border-footer-muted" onSubmit={(event) => {event.preventDefault(); if(email) setSent(true)}}><input value={email} onChange={(event) => setEmail(event.target.value)} type="email" required placeholder="Email address" className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none placeholder:text-footer-muted"/><button aria-label="Subscribe" className="px-2">→</button></form>}</div>
    </div>
    <div className="border-t border-footer-muted/30 py-6 text-center text-[10px] uppercase tracking-[0.18em] text-footer-muted">© 2026 Maison Boutique. All rights reserved.</div>
  </footer>;
}

export function ArrowLink({ to, children, light = false }: { to: "/collection" | "/about" | "/new-arrivals"; children: ReactNode; light?: boolean }) {
  return <Link to={to} className={light ? "button-light" : "button-dark"}>{children}<span aria-hidden>→</span></Link>;
}

export function SectionIntro({ eyebrow, title, copy }: { eyebrow: string; title: string; copy?: string }) {
  return <div className="mb-10 max-w-2xl"><p className="eyebrow">{eyebrow}</p><h2 className="section-title">{title}</h2>{copy && <p className="mt-4 text-sm leading-7 text-muted-foreground">{copy}</p>}</div>;
}