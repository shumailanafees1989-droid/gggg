import { createFileRoute } from "@tanstack/react-router";
import { Heart, SlidersHorizontal, X } from "lucide-react";
import { useMemo, useState } from "react";
import { MaisonShell } from "@/components/maison-shell";
import { collectionProducts } from "@/lib/maison-data";

export const Route = createFileRoute("/collection")({
  head: () => ({ meta: [
    { title: "The Autumnal Wardrobe — Maison" },
    { name: "description", content: "Explore Maison outerwear, silk blouses, knitwear, tailoring, and evening wear." },
    { property: "og:title", content: "The Autumnal Wardrobe — Maison" },
    { property: "og:description", content: "A curated wardrobe of limited-run pieces from our Paris atelier." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ]}), component: CollectionPage,
});

function CollectionPage() {
  const [category, setCategory] = useState("All");
  const [sort, setSort] = useState("Featured");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [favorite, setFavorite] = useState<string[]>([]);
  const [quickView, setQuickView] = useState<(typeof collectionProducts)[number] | null>(null);
  const shown = useMemo(() => {
    const filtered = category === "All" ? [...collectionProducts] : collectionProducts.filter((product) => product.category === category);
    if (sort === "Price: Low to High") filtered.sort((a,b) => a.price-b.price);
    if (sort === "Price: High to Low") filtered.sort((a,b) => b.price-a.price);
    return filtered;
  }, [category, sort]);
  const categories = ["All", "Outerwear", "Knitwear", "Tailoring", "Evening Wear", "Silk Blouses"];
  return <MaisonShell>
    <section className="border-b border-border"><div className="page-wrap py-16 md:py-24"><p className="eyebrow">Avenue Montaigne Collection</p><div className="mt-3 flex flex-wrap items-end justify-between gap-5"><h1 className="font-display text-5xl md:text-7xl">The Autumnal Wardrobe</h1><p className="text-xs uppercase tracking-[.15em] text-muted-foreground">Showing {shown.length} of 128 pieces</p></div></div></section>
    <div className="page-wrap py-10">
      <div className="mb-8 flex items-center justify-between border-b border-border pb-5 lg:justify-end"><button className="button-dark lg:hidden" onClick={() => setFiltersOpen(true)}><SlidersHorizontal size={15}/> Filters</button><label className="flex items-center gap-3 text-xs uppercase tracking-[.12em]">Sort By:<select className="field" value={sort} onChange={(e) => setSort(e.target.value)}><option>Featured</option><option>Price: Low to High</option><option>Price: High to Low</option><option>Newest</option></select></label></div>
      <div className="grid gap-10 lg:grid-cols-[220px_1fr]">
        <aside className={`${filtersOpen ? "fixed inset-0 z-[60] overflow-y-auto bg-background p-6" : "hidden"} lg:static lg:block lg:p-0`}><div className="mb-8 flex items-center justify-between"><h2 className="font-display text-2xl">Filters</h2><button className="icon-button lg:hidden" onClick={() => setFiltersOpen(false)} aria-label="Close filters"><X size={18}/></button></div><button className="mb-8 text-[11px] uppercase tracking-[.12em] underline" onClick={() => setCategory("All")}>Reset All</button><p className="eyebrow mb-4">Category</p><div className="grid gap-3">{categories.map((item) => <label className="flex items-center gap-3 text-sm" key={item}><input type="radio" checked={category === item} onChange={() => {setCategory(item);setFiltersOpen(false)}}/>{item}</label>)}</div><div className="mt-10 border-t border-border pt-7"><p className="eyebrow mb-4">Size</p><div className="flex gap-2">{["XS","S","M","L"].map(size => <button key={size} className="grid size-10 place-items-center border border-border text-xs hover:border-foreground">{size}</button>)}</div></div><div className="mt-10 border-t border-border pt-7"><p className="eyebrow mb-4">Colorway</p><div className="grid gap-3 text-sm"><span>● Noir</span><span>○ Ecru</span><span className="text-primary">● Camel</span><span className="text-muted-foreground">● Charcoal</span></div></div></aside>
        <div className="grid gap-x-5 gap-y-12 sm:grid-cols-2 xl:grid-cols-3">{shown.map(product => <article key={product.name} className="group"><div className="image-zoom relative aspect-[3/4] bg-secondary"><img src={product.image} alt={product.name} className="editorial-image"/><button className="icon-button absolute right-3 top-3 bg-background/90" onClick={() => setFavorite((items) => items.includes(product.name) ? items.filter(x => x !== product.name) : [...items, product.name])} aria-label={`Favorite ${product.name}`}><Heart size={17} fill={favorite.includes(product.name) ? "currentColor" : "none"}/></button><button className="absolute inset-x-4 bottom-4 translate-y-2 bg-background py-3 text-xs uppercase tracking-[.15em] opacity-0 group-hover:translate-y-0 group-hover:opacity-100" onClick={() => setQuickView(product)}>Quick View</button></div><p className="eyebrow mt-5">{product.category}</p><h2 className="mt-2 font-display text-xl">{product.name}</h2><p className="mt-2 text-xs text-muted-foreground">{product.detail}</p><p className="mt-3 text-sm">${product.price.toLocaleString()}</p></article>)}</div>
      </div><div className="py-20 text-center"><p className="mb-5 text-xs text-muted-foreground">Showing {shown.length} of 128 items</p><button className="button-dark">Load More Pieces</button></div>
    </div>
    {quickView && <div className="fixed inset-0 z-[70] grid place-items-center bg-overlay p-5" onClick={() => setQuickView(null)}><div className="grid max-w-3xl overflow-hidden bg-background sm:grid-cols-2" onClick={e => e.stopPropagation()}><img src={quickView.image} alt={quickView.name} className="h-full max-h-[70vh] w-full object-cover"/><div className="relative p-8"><button className="icon-button absolute right-3 top-3" onClick={() => setQuickView(null)}><X size={18}/></button><p className="eyebrow mt-8">{quickView.category}</p><h2 className="mt-3 font-display text-3xl">{quickView.name}</h2><p className="mt-4 text-sm text-muted-foreground">{quickView.detail}</p><p className="my-7 text-lg">${quickView.price.toLocaleString()}</p><button className="button-dark w-full">Add to Bag</button></div></div></div>}
  </MaisonShell>;
}