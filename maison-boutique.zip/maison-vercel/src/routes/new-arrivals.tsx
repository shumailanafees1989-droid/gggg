import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLink, MaisonShell, SectionIntro } from "@/components/maison-shell";
import { images } from "@/lib/maison-data";

export const Route = createFileRoute("/new-arrivals")({
  head: () => ({ meta: [
    { title: "The Nocturne Monolith — Maison" }, { name: "description", content: "Discover Maison Capsule N° 04: architectural tailoring, midnight silks, and heavyweight virgin wools." },
    { property: "og:title", content: "The Nocturne Monolith — Maison" }, { property: "og:description", content: "Maison Capsule N° 04, individually numbered and handcrafted in Paris and Milan." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }, { property: "og:image", content: images.newHero }, { name: "twitter:image", content: images.newHero },
  ]}), component: NewArrivalsPage,
});

function NewArrivalsPage() {
  const [joined, setJoined] = useState(false);
  const drops = [
    ["Limited Edition • 12/50", "Paris Atelier", "Sartorial Asymmetric Trench", "100% Double-Face Cashmere • Hand-stitched edges", "€2,450", images.new1],
    ["Exclusive Drop", "Milan Atelier", "Organza Sculptural Blouse", "Silk Organza • Mother-of-pearl buttons", "€980", images.new2],
    ["Limited Edition • 05/20", "Milan Atelier", "Pleated Wide-Leg Trouser", "Virgin Wool Twill • High-rise fit", "€1,150", images.new3],
    ["Limited Edition • 08/30", "Paris Atelier", "Architectural Ribbed Pullover", "Geelong Lambswool • Hand-linked seams", "€1,320", images.new4],
  ];
  return <MaisonShell>
    <section className="relative min-h-[640px] bg-foreground text-background"><img src={images.newHero} alt="Model in charcoal architectural tailoring" className="absolute inset-0 size-full object-cover"/><div className="absolute inset-0 bg-overlay"/><div className="page-wrap relative flex min-h-[640px] items-end pb-16"><div className="max-w-3xl"><p className="mb-5 text-xs uppercase tracking-[.2em]">Capsule N° 04 — Paris / Milan</p><h1 className="font-display text-5xl md:text-7xl">The Nocturne Monolith</h1><p className="mt-5 max-w-xl text-sm leading-7 text-background/80">A study in architectural tailoring, midnight silks, and heavyweight virgin wools forged in historic European ateliers.</p><div className="mt-8 flex gap-3"><ArrowLink to="/collection" light>Explore Drop</ArrowLink><a href="#registry" className="button-light">Private Viewing</a></div></div></div></section>
    <section className="page-wrap py-24"><SectionIntro eyebrow="New Releases" title="The Atelier Archives"/><div className="mb-10 flex flex-wrap gap-5 border-b border-border pb-5 text-[11px] uppercase tracking-[.15em]"><button>All Drops</button><button>Parisian Atelier</button><button>Milanese Tailoring</button><button>Limited Edition</button></div><div className="grid gap-x-6 gap-y-16 sm:grid-cols-2">{drops.map((p,i) => <article key={p[2]} className={i % 2 ? "sm:mt-24" : ""}><div className="image-zoom aspect-[4/5]"><img src={p[5]} alt={p[2]} className="editorial-image"/></div><div className="mt-5 flex justify-between gap-4"><div><p className="eyebrow">{p[0]}</p><p className="mt-4 text-[10px] uppercase tracking-[.15em] text-muted-foreground">{p[1]}</p><h2 className="mt-2 font-display text-2xl">{p[2]}</h2><p className="mt-2 text-xs text-muted-foreground">{p[3]}</p></div><p className="text-sm">{p[4]}</p></div></article>)}</div></section>
    <section className="grid bg-secondary md:grid-cols-2"><div className="min-h-[520px]"><img src={images.hands} alt="Artisan hand finishing a garment" className="size-full object-cover"/></div><div className="flex items-center px-6 py-20 md:px-[8vw]"><div><p className="eyebrow">The Savoir-Faire</p><h2 className="section-title">Where Heritage Meets Modern Avant-Garde</h2><p className="mt-7 text-sm leading-7 text-muted-foreground">Every garment in this drop is individually numbered and handcrafted by master artisans in our private ateliers across Rue Saint-Honoré and Via Montenapoleone.</p><div className="mt-10 flex gap-12"><div><b className="font-display text-4xl">50</b><p className="mt-2 text-[10px] uppercase tracking-[.14em]">Max Pieces Worldwide</p></div><div><b className="font-display text-4xl">100%</b><p className="mt-2 text-[10px] uppercase tracking-[.14em]">Traceable European Fibers</p></div></div></div></div></section>
    <section id="registry" className="page-wrap py-24 text-center"><p className="eyebrow">Private Client Registry</p><h2 className="mt-3 font-display text-4xl">Gain Priority Access to Future Drops</h2><p className="mx-auto mt-4 max-w-xl text-sm text-muted-foreground">Subscribers receive private digital viewings 24 hours prior to public release.</p>{joined ? <p className="mt-8 text-sm font-medium">Your private invitation is reserved.</p> : <form className="mx-auto mt-8 flex max-w-lg" onSubmit={(e) => {e.preventDefault();setJoined(true)}}><input type="email" required className="field min-w-0 flex-1" placeholder="Email address"/><button className="button-dark">Join</button></form>}</section>
  </MaisonShell>;
}