import { createFileRoute, Link } from "@tanstack/react-router";
import { LockKeyhole, Minus, Plus, ShieldCheck, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { MaisonShell } from "@/components/maison-shell";
import { images } from "@/lib/maison-data";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [
    { title: "Your Shopping Bag — Maison" }, { name: "description", content: "Review your selected Maison pieces and continue to secure checkout." },
    { property: "og:title", content: "Your Shopping Bag — Maison" }, { property: "og:description", content: "Maison private client shopping bag." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ]}), component: CartPage,
});

const startingItems = [
  { id: 1, name: "Structured Wool Blazer", price: 1450, size: "38 FR", color: "Noir", image: images.cart1, qty: 1 },
  { id: 2, name: "Pleated Silk Midi Skirt", price: 890, size: "36 FR", color: "Champagne", image: images.cart2, qty: 1 },
];

function CartPage() {
  const [items, setItems] = useState(startingItems);
  const [promo, setPromo] = useState("");
  const [message, setMessage] = useState("");
  const subtotal = useMemo(() => items.reduce((sum,item) => sum + item.price * item.qty, 0), [items]);
  const tax = subtotal * .08;
  const update = (id:number, change:number) => setItems(list => list.map(item => item.id === id ? {...item, qty: Math.max(1,item.qty+change)} : item));
  return <MaisonShell>
    <section className="page-wrap py-14 md:py-20"><p className="eyebrow">Avenue Montaigne, Paris</p><div className="mt-3 flex flex-wrap items-center justify-between gap-4"><h1 className="font-display text-5xl md:text-7xl">Your Shopping Bag</h1><p className="flex items-center gap-2 text-[10px] uppercase tracking-[.15em] text-muted-foreground"><LockKeyhole size={13}/>Secure Encrypted Session</p></div></section>
    <section className="page-wrap grid gap-12 pb-24 lg:grid-cols-[1fr_380px]">
      <div><div className="flex justify-between border-b border-border pb-4"><h2 className="text-xs font-semibold uppercase tracking-[.15em]">Selected Pieces ({items.length})</h2><span className="text-xs text-muted-foreground">Complimentary Packaging Included</span></div>{items.length ? items.map(item => <article key={item.id} className="grid grid-cols-[110px_1fr] gap-5 border-b border-border py-7 sm:grid-cols-[160px_1fr]"><img src={item.image} alt={item.name} className="aspect-[3/4] size-full object-cover"/><div className="flex flex-col justify-between"><div><p className="eyebrow">Maison Privé</p><div className="mt-2 flex justify-between gap-3"><h3 className="font-display text-xl sm:text-2xl">{item.name}</h3><p className="text-sm">${(item.price*item.qty).toLocaleString()}.00</p></div><p className="mt-4 text-xs text-muted-foreground">Size: <b className="text-foreground">{item.size}</b> · Color: <b className="text-foreground">{item.color}</b></p></div><div className="mt-6 flex items-center justify-between"><div className="flex items-center border border-border"><button className="icon-button rounded-none" onClick={() => update(item.id,-1)} aria-label="Decrease quantity"><Minus size={13}/></button><span className="w-8 text-center text-sm">{item.qty}</span><button className="icon-button rounded-none" onClick={() => update(item.id,1)} aria-label="Increase quantity"><Plus size={13}/></button></div><button className="flex items-center gap-2 text-xs uppercase tracking-[.1em] text-muted-foreground" onClick={() => setItems(list => list.filter(x => x.id !== item.id))}><Trash2 size={14}/>Remove</button></div></div></article>) : <div className="py-24 text-center"><ShoppingEmpty/><Link to="/collection" className="button-dark mt-6">Explore Collection</Link></div>}
        <div className="mt-8 flex gap-4 bg-secondary p-6"><ShieldCheck className="shrink-0"/><div><h3 className="font-display text-lg">Maison Concierge Guarantee</h3><p className="mt-2 text-xs leading-6 text-muted-foreground">Every order is hand-inspected, beautifully gift-wrapped in signature Maison packaging, and insured for transit.</p></div></div>
      </div>
      <aside className="h-fit bg-secondary p-7 lg:sticky lg:top-28"><h2 className="font-display text-3xl">Order Summary</h2><div className="mt-7 grid gap-4 border-y border-border py-6 text-sm"><div className="flex justify-between"><span>Subtotal</span><span>${subtotal.toLocaleString()}.00</span></div><div className="flex justify-between"><span>Complimentary Shipping</span><span>Free</span></div><div className="flex justify-between"><span>Estimated Tax</span><span>${tax.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}</span></div></div><div className="flex justify-between py-6 text-lg font-semibold"><span>Total</span><span>${(subtotal+tax).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}</span></div><p className="eyebrow mb-3">Private Invitation / Promo Code</p><form className="flex" onSubmit={(e) => {e.preventDefault();setMessage(promo.toUpperCase()==="MAISON10" ? "Invitation applied." : "Invitation code not recognized.")}}><input className="field min-w-0 flex-1" value={promo} onChange={e=>setPromo(e.target.value)} aria-label="Promo code"/><button className="button-dark">Apply</button></form>{message && <p className="mt-2 text-xs">{message}</p>}<button className="button-dark mt-6 w-full" onClick={() => setMessage(items.length ? "Secure checkout is ready for connection." : "Your bag is empty.")}><LockKeyhole size={14}/>Proceed to Secure Checkout</button><p className="mt-4 text-center text-[10px] uppercase tracking-[.12em] text-muted-foreground">Amex · Visa · Mastercard · Apple Pay</p></aside>
    </section>
    <section className="bg-secondary py-20"><div className="page-wrap"><div className="flex items-end justify-between"><div><p className="eyebrow">Complete Your Look</p><h2 className="mt-2 font-display text-4xl">Frequently Paired With</h2></div><Link to="/collection" className="hidden text-xs uppercase tracking-[.14em] underline sm:block">View Entire Collection</Link></div><div className="mt-10 grid gap-5 sm:grid-cols-3">{[["Montaigne Leather Tote","$1,850.00","Calfskin / Noir",images.tote],["Pearl Drop Earrings","$420.00","18k Gold Vermeil",images.earrings],["Geometric Silk Scarf","$340.00","Pure Mulberry Silk",images.scarf]].map(p=><article key={p[0]}><div className="aspect-square image-zoom"><img src={p[3]} alt={p[0]} className="editorial-image"/></div><div className="mt-4 flex justify-between"><div><h3 className="font-display text-xl">{p[0]}</h3><p className="mt-1 text-xs text-muted-foreground">{p[2]}</p></div><span className="text-sm">{p[1]}</span></div></article>)}</div></div></section>
  </MaisonShell>;
}

function ShoppingEmpty(){ return <><p className="font-display text-3xl">Your bag is awaiting its first piece.</p><p className="mt-3 text-sm text-muted-foreground">Explore the latest Maison collection.</p></> }