import { createFileRoute } from "@tanstack/react-router";
import { ArrowLink, MaisonShell, SectionIntro } from "@/components/maison-shell";
import { images } from "@/lib/maison-data";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Maison Paris — Autumn/Winter 2025" },
    { name: "description", content: "Discover Maison's Autumn/Winter 2025 collection, crafted in limited runs at our Paris atelier." },
    { property: "og:title", content: "Maison Paris — Autumn/Winter 2025" },
    { property: "og:description", content: "An uncompromising exploration of silhouette, texture, and silence." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
    { property: "og:image", content: images.homeHero }, { name: "twitter:image", content: images.homeHero },
  ]}), component: HomePage,
});

function HomePage() {
  const categories = [["Evening Wear", images.evening], ["Tailored Blazers", images.blazer], ["Silk Blouses", images.blouse], ["Accessories", images.accessories]];
  const looks = [["Look 01", "The Montaigne Ensemble", images.look1], ["Look 02", "Nocturne Silhouettes", images.look2], ["Look 03", "The Atelier Cut", images.look3]];
  return <MaisonShell>
    <section className="relative min-h-[calc(100vh-5rem)] overflow-hidden bg-foreground text-background">
      <img src={images.homeHero} alt="Model wearing a sculptural black coat in a Parisian interior" className="absolute inset-0 size-full object-cover object-center" />
      <div className="absolute inset-0 bg-overlay" />
      <div className="page-wrap relative flex min-h-[calc(100vh-5rem)] items-end pb-16 pt-36 md:items-center md:pb-0">
        <div className="max-w-3xl"><p className="mb-5 text-xs uppercase tracking-[.2em]">Avenue Montaigne, Paris</p><h1 className="font-display text-5xl leading-[.95] font-medium sm:text-7xl lg:text-[5.5rem]">Autumn/Winter<br/>2025 Collection</h1><p className="mt-6 max-w-xl text-sm leading-7 text-background/85">An uncompromising exploration of silhouette, texture, and silence. Crafted for the modern connoisseur of understated luxury.</p><div className="mt-8 flex flex-wrap gap-3"><ArrowLink to="/collection" light>Shop Now</ArrowLink><ArrowLink to="/about" light>Discover Story</ArrowLink></div></div>
      </div>
    </section>
    <section className="page-wrap py-24"><SectionIntro eyebrow="The Wardrobe" title="Curated Categories" copy="Each piece is individually numbered and constructed in limited runs within our Parisian atelier."/><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{categories.map(([name,image]) => <a href="/collection" key={name} className="group image-zoom relative aspect-[3/4]"><img src={image} alt={name} className="editorial-image"/><div className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-background/90 p-5"><span className="font-display text-xl">{name}</span><span>→</span></div></a>)}</div></section>
    <section className="bg-secondary py-24"><div className="page-wrap"><SectionIntro eyebrow="Editorial Visuals" title="The Lookbook"/><div className="grid gap-5 md:grid-cols-3">{looks.map(([label,title,image]) => <article key={label}><div className="image-zoom aspect-[4/5]"><img src={image} alt={title} className="editorial-image"/></div><p className="eyebrow mt-5">{label}</p><h3 className="mt-2 font-display text-2xl">{title}</h3></article>)}</div></div></section>
    <section className="grid md:grid-cols-2"><div className="flex items-center px-5 py-20 md:px-[10vw]"><div><p className="eyebrow">Maison Heritage</p><h2 className="section-title">Where timeless craft meets modern architectural restraint.</h2><p className="my-7 max-w-xl text-sm leading-7 text-muted-foreground">Founded in the heart of Paris, Maison is dedicated to the preservation of master tailoring techniques. We source only the rarest organic fibers from sustainable mills across Europe.</p><ArrowLink to="/about">Read Our Philosophy</ArrowLink></div></div><div className="min-h-[520px]"><img src={images.atelier} alt="Tailor hand-stitching a wool lapel" className="size-full object-cover"/></div></section>
  </MaisonShell>;
}